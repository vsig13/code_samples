from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404
from django.views.generic import TemplateView
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import permissions

from .models import Domain
from .serializers import DomainSerializer


class IsAbleToAdd(permissions.BasePermission):
    def has_permission(self, request, view):
        if request.method == 'POST':
            return request.user.get_username() == 'manager'
        else:
            return True


class Index(LoginRequiredMixin, TemplateView):
    login_url = '/login/'
    template_name = 'index.html'


class DomainViewset(viewsets.ModelViewSet):
    queryset = Domain.objects.all()
    serializer_class = DomainSerializer
    permission_classes = (IsAbleToAdd, )

    def get_queryset(self):
        return Domain.objects.filter(is_private__in=(
                0, self.request.user.is_authenticated()))

    def retrieve(self, request, pk=None):
        domain = get_object_or_404(self.get_queryset(), pk=pk)
        serializer = DomainSerializer(domain)
        return Response(serializer.data)
