import requests
from rest_framework import serializers
from mainapp.models import Domain


class DomainSerializer(serializers.ModelSerializer):
    class Meta:
        model = Domain
        fields = ('pk', 'domain', 'is_private')

    def validate_domain(self, value):
        if value.startswith('https://'):
            # return True

            try:
                requests.head(value)
            except Exception as e:
                print(e)
                raise serializers.ValidationError('Domain could not be reached')
            else:
                return value
        else:
            raise serializers.ValidationError('Must start from "https://"')
