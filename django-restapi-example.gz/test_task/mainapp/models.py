from django.db import models


class DomainManager(models.Manager):
    def get_by_natural_key(self, domain, is_private):
        return self.get(domain__iexact=domain, is_private=is_private)


class Domain(models.Model):
    class Meta:
        ordering = ('domain', '-is_private')
        unique_together = (('domain', 'is_private'))

    domain = models.CharField(max_length=253)
    is_private = models.IntegerField(default=0)

    objects = DomainManager()

    def __str__(self):
        return '{} ({})'.format(
            self.domain, ('public', 'private')[self.is_private])

    def natural_key(self):
        return (self.domain, self.is_private, )
