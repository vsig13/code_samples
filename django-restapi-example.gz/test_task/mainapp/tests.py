from django.core.urlresolvers import reverse
from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.test import APIClient, APITestCase, force_authenticate
from mainapp.models import Domain


class DomainTests(APITestCase):
    def setUp(self):
        self.domains = [
            ('https://wikipedia.org', 0),
            ('https://wiki.archlinux.org', 0),
            ('https://github.org', 1),
            ('https://www.sans.org', 1),
            ('https://wiki.tcl.tk', 0),
        ]
        self.keys = ('domain', 'is_private')

        self.csrf_client = APIClient(enforce_csrf_checks=True)
        self.non_csrf_client = APIClient(enforce_csrf_checks=False)

        self.username = 'manager'
        self.passwd = 'test_account'
        self.user = User.objects.create_user(
            username=self.username,
            email='email@x.com',
            password=self.passwd)

    def test_create_domain_as_anonymous(self):
        """Anonymous user should not be able to create new domains, therefore
        401 code response from server is expected.
        """
        url = reverse('domains-list')

        for domain in self.domains:
            response = self.non_csrf_client.post(
                url, dict(zip(self.keys, domain), format='json'))
            self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
        self.assertEqual(Domain.objects.count(), 0)

    def test_create_domain_as_manager(self):
        """Username 'manager' is allowed to create domains. Code 201 expected.
        """
        url = reverse('domains-list')
        self.non_csrf_client.login(username=self.username, password=self.passwd)

        # Iterate over all tested domains and check status codes
        for domain in self.domains:
            response = self.non_csrf_client.post(
                url, dict(zip(self.keys, domain), format='json'))
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # All entities must be accessible
        self.assertEqual(Domain.objects.count(), len(self.domains))

    def test_domain_access_permissions(self):
        """Test access rights to private domains
        """
        self.non_csrf_client.logout()
        response = self.non_csrf_client.get(reverse('domains-list'))
        private_count = Domain.objects.filter(is_private=True).count()
        self.assertEqual(len(response.data), private_count)

        self.non_csrf_client.login(username=self.username, password=self.passwd)
        private_count = Domain.objects.filter(is_private=False).count()
        self.assertEqual(len(response.data), private_count)
