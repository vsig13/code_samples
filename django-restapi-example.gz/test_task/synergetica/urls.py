from django.conf.urls import include, url
from django.contrib import admin, auth
from mainapp import views


domain_list = views.DomainViewset.as_view({
    'get': 'list',
    'post': 'create'
})

domain_retrieve = views.DomainViewset.as_view({
    'get': 'retrieve'
})


urlpatterns = [
    url(r'^(index/?)?/?$', views.Index.as_view(), name='index'),

    url('^login/?$', auth.views.login),
    url('^logout/?$', auth.views.logout),


    url('^api/?$', domain_list, name='domains-list'),
    url('^api/:(?P<pk>\d+)/?$', domain_retrieve, name='domains-retrieve'),

    url(r'^admin/', admin.site.urls),
]
